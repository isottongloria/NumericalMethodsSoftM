/* compile to create an executable "EX1",
   for example, with
     cc example-C-04.c -o EX4

   With this example you will learn:
   - "for" cycles
   - pass variables to functions
   - pointers
   - memory allocation
   
   */

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>


void collect_histogram(double *data, int data_size, double *_out, double min, double binsize, int nbins)
{
    int i;
    int temp;

    for(i = 0; i < data_size; i++){
       temp = (int) floor((data[i] - min)/binsize);
       if(temp > nbins-1) continue; // continue command skips what remain in the loop from thant point on
       _out[temp] += 1;
    }

}

/*
void normalize_histogram()
{


}
*/


int main( int argc, char **argv)
{
    float *mypointer=NULL;
    int i;
    
    //Allocating pointers: malloc and calloc
    // malloc only reserves memory but does not initialize
    mypointer = (float*) malloc (10*sizeof(float));
    // freeing memory
    free(mypointer);
    // calloc also initializes to zeros
    mypointer = (float*) calloc (10, sizeof(float));
    free(mypointer);

    int nbins = 100; //bin_edges = nbins+1
    //Allocate the pointer to accumulate data for an histogram
    double *myhist = NULL;
    myhist = (double*) calloc (nbins, sizeof(double));
    
    double min = 0;
    double max = 1;
    double binsize = (max-min)/(nbins);

    //Alternative: in-line definition+allocation
    //double *myhist = (double*) calloc (nbins, sizeof(double));
    
    double *test = (double*) malloc(1*sizeof(double)); test[0] = 0.9999;  
    collect_histogram(test, 1, myhist, min, binsize, nbins);
    
    test[0] = 0.001;
    collect_histogram(test, 1, myhist, min, binsize, nbins);

    //for(i=0; i < nbins; i++){ printf("%.5g %.5g\n", min+(i+0.5)*binsize, myhist[i] );}
   
    free(myhist); free(test);

    return 0;
}


