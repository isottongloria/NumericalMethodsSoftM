/*
  With this example you will learn:
   - input/output from file
   
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void Read_file() {
  FILE* file = fopen("myfile.dat", "r"); //limitation 1: dovrei mettere il nome del file compile time (come input della funzione)
                                         // limitation 2: dovrei controllare che il file esiste
                                         
  char line[1000]; // Warning: max 1000 chars
  
  while (fgets(line, sizeof(line), file) != NULL) {
    // Tokenize the line based on spaces and tabs
    char* token = strtok(line, " \t");
    
    // Print each token
    while (token != NULL) {
      // assuming tokens are floats
      printf("%.5g ", atof(token));
      token = strtok(NULL, " \t");
    }
    printf("\n");
  }
  
  fclose(file);
}

int main() {
  Read_file();
  return 0;
}

