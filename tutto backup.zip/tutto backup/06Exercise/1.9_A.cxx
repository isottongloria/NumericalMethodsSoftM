/*  Off lattice 3D Monte Carlo simulation
*
*/
#include <iostream>
#include <fstream>
#include <cmath>
#include <random>
#include <cstdlib>
#include <ctime>
#include <numeric>

#include "definitions.h"
#include "random.h"
#include "energy.h"

using namespace std;

void init_Positions(double **X)
{

    // Initialize the matrix with random values for positions x, y, z
    for (int i = 0; i < mySys.NPart; i++)
    {
     	X[i][0] = ran38(&(mySys.seed))*mySys.box_x; // x position
        X[i][1] = ran38(&(mySys.seed))*mySys.box_y; // y position
        X[i][2] = ran38(&(mySys.seed))*mySys.box_z; // z position
    }

    // Print the matrix for verification
    cout << "Matrix X:" << endl;
    for (int i = 0; i < mySys.NPart; i++)
    {
        for (int j = 0; j < 3.0; j++)
        {
            cout << X[i][j] << " ";
        }
        cout << endl;
    }
}

int main(int argc, const char * argv[]) {

	const double K_B = 8.617343e-5; // Boltzmann's constant in natural uni
	mySys.NPart = 10;     // number of particles
	mySys.disp_max = 0.1; // max displacement
	mySys.NSteps = 100;   // monte carlo steps
	mySys.T = 2;          // temperature
	mySys.energy = 0.;     // initialize energy to zero
	mySys.energy_curr = 0.;
	mySys.seed = time(0); // seed for random number generator 
	mySys.box_x = 1.;
	mySys.box_y = 1.;
	mySys.box_z = 1.;
	mySys.sigma = 1.0;
	mySys.eps = 1.0;
	mySys.disp_max = 0.2; // set max displacement
	const double beta = 1.0 / ( K_B * mySys.T );
	int i_star = 0;       // index of particle to displace
	double diff_ene = 0.0; // difference of energy between config
	double u = 0.0;       // random uniform number
	double ratio = 0.0;   // metropolis ratio
	double proposed_position = 0.0; 
	
	// ********* Allocate memory for the matrix (NPartx3) *********
	double **X = (double **)malloc(mySys.NPart * sizeof(double *));    	
   	for (int i = 0; i < mySys.NPart; i++){
    	    X[i] = (double *)malloc(3.0 * sizeof(double));
    	}
    	
    	// ********* Call the initialization function *********
    	init_Positions(X); 							

	// ********* Compute the energy of the system before displ *******
	mySys.energy = compute_energy(X, mySys.sigma, mySys.eps);
        cout << mySys.energy << endl;
        	
	// ********* Propose a displacement in each direction ****
	i_star = ran38(&(mySys.seed)) * mySys.NPart;  // pick a particle at random
	for (int j = 0; j < 3; j++){
            proposed_position = X[i_star][j] - mySys.disp_max + ran38(&(mySys.seed)) * (2.0 * mySys.disp_max); // x displacement
            
            // Apply periodic boundary conditions using the formula
    	    X[i_star][j] = X[i_star][j] - floor(proposed_position / mySys.box_x) * mySys.box_x;

        }
        
        mySys.energy_curr = compute_energy(X, mySys.sigma, mySys.eps);
        cout << mySys.energy_curr << endl;


	//********** Accept or reject according to the Metropolis rule ***********
	diff_ene = mySys.energy_curr - mySys.energy ; // delta energy if I accept that flip
        ratio = exp((-diff_ene)/beta);
        u = ran38(&(mySys.seed)); // uniform real number in [0,1]
		
	if (diff_ene <= 0.0 || u < ratio) {
		cout << "accept";
	}








    	// ********* Deallocate memory for the matrix ********* 
    	for (int i = 0; i <  mySys.NPart; i++)
    	{
        	free(X[i]);
    	}
    	free(X);
	
    return 0;
}	


        // ********* to draw a random number *********
        // double random_value = ran38(&(mySys.seed));
  

/*for (int i = 0; i < mySys.NPart; ++i) {
		for (int j = 0; j < mySys.NPart; ++j) {
			for (int k = 0; k < mySys.NPart; ++k) {
				if (icount < mySys.NPart) {
				    L = mySys.box_x;
				} else if (icount < 2 * mySys.NPart) {
				    L = mySys.box_y;
				} else {
				    L = mySys.box_z;
				}

				x[icount] = distribution2(generator) * L;
				cout << x[icount] << " ";
				icount++;
			    }
			cout << endl;
		}
	        cout << endl;
	    }*/
