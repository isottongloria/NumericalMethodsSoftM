extern RngStream rngs;
